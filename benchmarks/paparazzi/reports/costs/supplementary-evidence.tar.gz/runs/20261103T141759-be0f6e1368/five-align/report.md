# five-align / 20261103T141759-be0f6e1368

Verification: passed

CompCert provenance freshly audited; no delivery approval issued.

Wall time: 0.059327 s

CPU tool time: 0.01 s

Observed tool-tree RSS peak: 23293952 bytes

Model tokens: unavailable; total=None

Measurement completeness: partial

run.json contains scope, input/output hashes, commands, token evidence and remaining obligations. metrics.json contains resource measurements and their limits.

Cost evidence audit: incomplete

- Tool replay is not a measured model-authoring stage

- Actual stage token receipt unavailable/incomplete

- Unidentified token source

- Token source has no receipt reference

- Missing/ambiguous captured usage receipt

- Aggregated token metrics incomplete

- Incorrect aggregate input_tokens

- Incorrect aggregate output_tokens

- Incorrect aggregate subset cached_input_tokens

- Incorrect aggregate subset reasoning_output_tokens

- Missing/invalid cost evidence: unsupported operand type(s) for +: 'NoneType' and 'NoneType'
