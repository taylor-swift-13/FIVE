# five-align / 20261104T025956-c73e9d8bbc

Verification: passed

CompCert model and parameterized safety/termination targets generated and checked. Precondition authoring and program proofs were not attempted; full delivery remains pending.

Wall time: 38.162846 s

CPU tool time: 37.660000000000004 s

Observed tool-tree RSS peak: 1264508928 bytes

Model tokens: unavailable; total=None

Measurement completeness: partial

run.json contains scope, input/output hashes, commands, token evidence and remaining obligations. metrics.json contains resource measurements and their limits.

Cost evidence audit: incomplete

- Tool replay is not a measured model-authoring stage

- Actual stage token receipt unavailable/incomplete

- Unidentified token source

- Token source has no receipt reference

- Missing/ambiguous captured usage receipt

- Aggregated token metrics incomplete

- Incorrect aggregate input_tokens

- Incorrect aggregate output_tokens

- Incorrect aggregate subset cached_input_tokens

- Incorrect aggregate subset reasoning_output_tokens

- Missing/invalid cost evidence: unsupported operand type(s) for +: 'NoneType' and 'NoneType'
