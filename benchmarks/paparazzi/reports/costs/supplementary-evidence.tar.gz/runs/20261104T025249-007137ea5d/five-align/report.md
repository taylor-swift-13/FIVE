# five-align / 20261104T025249-007137ea5d

Verification: passed

138 state entries generated and audited. Horizontal guidance remains blocked by the missing genuine generated aircraft configuration.

Wall time: 1531.068006 s

CPU tool time: 460.7899999999999 s

Observed tool-tree RSS peak: 1452261376 bytes

Model tokens: available; total=29052971

Measurement completeness: partial

run.json contains scope, input/output hashes, commands, token evidence and remaining obligations. metrics.json contains resource measurements and their limits.

Cost evidence audit: incomplete

- Measurements are marked partial
