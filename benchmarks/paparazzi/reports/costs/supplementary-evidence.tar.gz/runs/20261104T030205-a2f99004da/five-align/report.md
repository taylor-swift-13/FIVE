# five-align / 20261104T030205-a2f99004da

Verification: passed

CompCert model and parameterized safety/termination targets generated and checked. Precondition authoring and program proofs were not attempted; full delivery remains pending.

Wall time: 38.956517 s

CPU tool time: 38.54 s

Observed tool-tree RSS peak: 1264410624 bytes

Model tokens: unavailable; total=None

Measurement completeness: partial

run.json contains scope, input/output hashes, commands, token evidence and remaining obligations. metrics.json contains resource measurements and their limits.

Cost evidence audit: incomplete

- Tool replay is not a measured model-authoring stage

- Actual stage token receipt unavailable/incomplete

- Unidentified token source

- Token source has no receipt reference

- Missing/ambiguous captured usage receipt

- Aggregated token metrics incomplete

- Incorrect aggregate input_tokens

- Incorrect aggregate output_tokens

- Incorrect aggregate subset cached_input_tokens

- Incorrect aggregate subset reasoning_output_tokens

- Missing/invalid cost evidence: unsupported operand type(s) for +: 'NoneType' and 'NoneType'
