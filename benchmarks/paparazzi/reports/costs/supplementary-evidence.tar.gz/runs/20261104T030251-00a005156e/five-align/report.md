# five-align / 20261104T030251-00a005156e

Verification: failed

failed: /home/yangfp/.opam/five/bin/clightgen exit=2; 
  }
}



static inline void float_mat_transpose(float **o, float **a, const int n, const int m)
{
  int i, j;
  for (i = 0; i < n; i++) {
    for (j = 0; j < m; j++) {
      o[j][i] = a[i][j];
    }
  }
}







static inline void float_mat_mul(float **o, float **a, float **b, const int m, const int n, const int l)
{
  int i, j, k;
  for (i = 0; i < m; i++) {
    for (j = 0; j < l; j++) {
      o[i][j] = 0.;
      for (k = 0; k < n; k++) {
        o[i][j] += a[i][k] * b[k][j];
      }
    }
  }
}







static inline void float_mat_mul_transpose(float **o, float **a, float **b, const int m, const int n, const int l)
{
  int i, j, k;
  for (i = 0; i < m; i++) {
    for (j = 0; j < l; j++) {
      o[i][j] = 0.;
      for (k = 0; k < n; k++) {
        o[i][j] += a[i][k] * b[j][k];
      }
    }
  }
}
# 791 "/home/yangfp/five/_build/paparazzi/state-guidance-overlay/math/pprz_algebra_float.h"
static inline void float_mat_vect_mul(float *o, float **a, const float *b, const int m, const int n)
{
  int i, j;
  for (i = 0; i < m; i++) {
    o[i] = 0;
    for (j = 0; j < n; j++) {
      o[i] += a[i][j] * b[j];
    }
  }
}






static inline void float_mat_scale(float **a, float k, const int m, const int n)
{
  int i, j;
  for (i = 0; i < m; i++) {
    for (j = 0; j < n; j++) {
      a[i][j] *= k;
    }
  }
}







static inline void float_mat_sum_scaled(float **a, float **b, const float k, const int m, const int n)
{
  int i, j;
  for (i = 0; i < m; i++) {
    for (j = 0; j < n; j++) {
      a[i][j] += k * b[i][j];
    }
  }
}
# 840 "/home/yangfp/five/_build/paparazzi/state-guidance-overlay/math/pprz_algebra_float.h"
static inline void float_mat_minor(float **o, float **a, const int m, const int n, const int d)
{
  int i, j;
  float_mat_zero(o, m, n);
  for (i = 0; i < d; i++) { o[i][i] = 1.0; }
  for (i = d; i < m; i++) {
    for (j = d; j < n; j++) {
      o[i][j] = a[i][j];
    }
  }
}


static inline void float_mat_vmul(float **o, const float *v, const int n)
{
  int i, j;
  for (i = 0; i < n; i++) {
    for (j = 0; j < n; j++) {
      o[i][j] = -2. * v[i] * v[j];
    }
  }
  for (i = 0; i < n; i++) {
    o[i][i] += 1.;
  }
}


static inline void float_mat_col(float *o, float **a, const int m, const int c)
{
  int i;
  for (i = 0; i < m; i++) {
    o[i] = a[i][c];
  }
}


static inline void float_mat_diagonal_scal(float **o, float v, const int n)
{
  int i, j;
  for (i = 0 ; i < n; i++) {
    for (j = 0 ; j < n; j++) {
      if (i == j) {
        o[i][j] = v;
      } else {
        o[i][j] = 0.0;
      }
    }
  }
}



static inline void float_mat_div_scalar(float **o, float **a, const float scalar, const int m, const int n)
{
  int i, j;
  for (i = 0; i < m; i++) {
    for (j = 0; j < n; j++) {
      o[i][j] = a[i][j] / scalar;
    }
  }
}


static inline void float_mat_mul_scalar(float **o, float **a, const float scalar, const int m, const int n)
{
  int i, j;
  for (i = 0; i < m; i++) {
    for (j = 0; j < n; j++) {
      o[i][j] = a[i][j] * scalar;
    }
  }
}



extern _Bool float_mat_inv_2d(float inv_out[4], const float mat_in[4]);
extern void float_mat2_mult(struct FloatVect2 *vect_out, const float mat[4], const struct FloatVect2 vect_in);
extern _Bool float_mat_inv_3d(float inv_out[3][3], const float mat_in[3][3]);
extern void float_mat3_mult(struct FloatVect3 *vect_out, const float mat[3][3], const struct FloatVect3 vect_in);
extern _Bool float_mat_inv_4d(float invOut[4][4], const float mat_in[4][4]);

extern void float_vect3_bound_in_2d(struct FloatVect3 *vect3, const float bound);
extern void float_vect3_bound_in_3d(struct FloatVect3 *vect3, const float bound);
extern void float_vect3_scale_in_2d(struct FloatVect3 *vect3, const float norm_des);
extern void float_vect2_bound_in_2d(struct FloatVect2 *vect2, const float bound);
extern void float_vect2_scale_in_2d(struct FloatVect2 *vect2, const float norm_des);
# 34 "/home/yangfp/five/_build/paparazzi/upstream/sw/airborne/firmwares/rotorcraft/guidance/guidance_h_ref.h" 2
; run=/home/yangfp/five/runs/20261104T030251-00a005156e/five-align

Wall time: 0.041577 s

CPU tool time: 0.0 s

Observed tool-tree RSS peak: 23420928 bytes

Model tokens: unavailable; total=None

Measurement completeness: partial

run.json contains scope, input/output hashes, commands, token evidence and remaining obligations. metrics.json contains resource measurements and their limits.

Cost evidence audit: incomplete

- Tool replay is not a measured model-authoring stage

- Actual stage token receipt unavailable/incomplete

- Unidentified token source

- Token source has no receipt reference

- Missing/ambiguous captured usage receipt

- Aggregated token metrics incomplete

- Incorrect aggregate input_tokens

- Incorrect aggregate output_tokens

- Incorrect aggregate subset cached_input_tokens

- Incorrect aggregate subset reasoning_output_tokens

- Missing/invalid cost evidence: unsupported operand type(s) for +: 'NoneType' and 'NoneType'
