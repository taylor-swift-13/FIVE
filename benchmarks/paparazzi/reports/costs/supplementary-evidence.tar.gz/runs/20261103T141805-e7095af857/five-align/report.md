# five-align / 20261103T141805-e7095af857

Verification: failed

Preprocessing/header/configuration drift

Wall time: 0.025013 s

CPU tool time: 0.01 s

Observed tool-tree RSS peak: 11845632 bytes

Model tokens: unavailable; total=None

Measurement completeness: partial

run.json contains scope, input/output hashes, commands, token evidence and remaining obligations. metrics.json contains resource measurements and their limits.

Cost evidence audit: incomplete

- Tool replay is not a measured model-authoring stage

- Actual stage token receipt unavailable/incomplete

- Unidentified token source

- Token source has no receipt reference

- Missing/ambiguous captured usage receipt

- Aggregated token metrics incomplete

- Incorrect aggregate input_tokens

- Incorrect aggregate output_tokens

- Incorrect aggregate subset cached_input_tokens

- Incorrect aggregate subset reasoning_output_tokens

- Missing/invalid cost evidence: unsupported operand type(s) for +: 'NoneType' and 'NoneType'
