# Paparazzi representative CompCert models

Pinned upstream: `abfee3dd56eeab12c528635504a429db3daf409a`.

Source inventory: 7457 syntactically recognized function definitions (6754 in .c, 703 in .h), 6237 unique names; 6708 airborne definitions. Includes conditional branches and platform variants. 319 nodes carry parser error flags and require review; this is not a firmware-linked count. See inventory.json.

45 new selected entries generated and source-audited across 10 modules. Existing lowpass, pid and attitude_trig cases were not regenerated. No program-property proofs or CBMC runs were attempted.

| Module | Selected entries | Status |
|---|---:|---|
| statistics | 7 | generated-and-audited |
| algebra | 8 | generated-and-audited |
| geodetic | 5 | generated-and-audited |
| decomposition | 4 | generation-gap |
| kalman | 3 | generated-and-audited |
| linear_kalman | 3 | generation-gap |
| median | 3 | generated-and-audited |
| highpass | 3 | generated-and-audited |
| notch | 3 | generated-and-audited |
| delay | 4 | generated-and-audited |
| ring_buffer | 5 | generated-and-audited |
| framed_buffer | 4 | generated-and-audited |

## Files

```text
inventory.json             full source function list, locations and counting policy
results.json               entry names, source hashes, audits and gaps
models/<module>/
  Program.c                unchanged source slices or header inclusion driver
  model/Source.v           CompCert Csyntax AST shared by the module entries
  model/compcert-manifest.json
  entries/<function>/
    Execution.v            unrestricted Cexec entry with memory-byte observations
    proof/Precondition.v   explicit precondition interface, pending
    proof/Obligations.v    no-error and all-executions termination propositions
    proof/Proofs.v         empty proof authoring location
```

The base model also contains the generator standard wrapper and primary-entry goal files. Each selected entry has its own corresponding four files. CompCert 3.17, x86-64 Linux little endian, binary32 round-to-nearest-even. Every successful AST/wrapper/goal declaration was typechecked; generation does not establish safety, termination or complete external-environment correspondence.

## Source preservation and coverage

Program.c keeps selected definitions and their source-level local call closure byte-for-byte. The overlay omits only the unrelated `float_mat_mul_copy` inline definition because its VLA prevents frontend import; no retained function body or C arithmetic is rewritten. Source-slice byte equality is checked in results.json; generated AST provenance audits are recorded separately. Upstream headers and implementation are retained in upstream/ at the pinned commit.

External library calls remain explicit environment interfaces in CompCert. No missing callback is classified as a C error. No libm implementation or callback correspondence is proved in this batch. Interfaces and remaining coverage are recorded in results.json and model manifests. Runtime-sized local arrays are left as frontend gaps, never replaced by guessed fixed dimensions.

## Remaining frontend gaps

- decomposition: CompCert rejects variable-length arrays; see results.json and the generation-run logs for exact locations.
- linear_kalman: CompCert rejects variable-length arrays; see results.json and the generation-run logs for exact locations.

## Selected functions

- statistics: `sum_f`, `mean_f`, `variance_f`, `covariance_f`, `mean_i`, `variance_i`, `covariance_i`
- algebra: `float_rmat_comp`, `float_rmat_vmult`, `float_quat_comp`, `float_quat_vmult`, `float_vect3_integrate_fi`, `float_mat_inv_2d`, `float_mat_inv_3d`, `float_rmat_reorthogonalize`
- geodetic: `enu_of_ecef_point_f`, `ned_of_ecef_vect_f`, `ecef_of_enu_point_f`, `ecef_of_lla_f`, `lla_of_ecef_f`
- kalman: `simple_kinematic_kalman_init`, `simple_kinematic_kalman_predict`, `simple_kinematic_kalman_update`
- median: `init_median_filter_f`, `update_median_filter_f`, `get_median_filter_f`
- highpass: `init_first_order_high_pass`, `update_first_order_high_pass`, `update_fourth_order_high_pass`
- notch: `notch_filter_init`, `notch_filter_update`, `notch_filter_set_filter_frequency`
- delay: `init_transport_delay`, `update_transport_delay`, `reset_transport_delay`, `get_transport_delay`
- ring_buffer: `ring_buffer_init`, `ring_buffer_write`, `ring_buffer_read`, `ring_buffer_available`, `ring_buffer_free_space`
- framed_buffer: `framed_ring_buffer_init`, `framed_ring_buffer_get`, `framed_ring_buffer_put`, `framed_ring_buffer_drop_last`

The scope is representative entry generation through align. Concrete preconditions, no-error, termination and execution-correspondence proofs remain pending.

Cost evidence: /home/yangfp/five/runs/20261103T135838-d67130d489/five-align; parent metrics aggregate the real sequential export/audit commands and entry checks, including failed attempts. Tool-only subruns have no separately attributed model tokens. The parent measured session owns the model work.

Generation issue count (module-level, not individual diagnostics): 12 discovered, 10 resolved, 2 unresolved frontend gaps. Two initially considered by-value-struct Kalman wrappers (update_pos/update_speed) were excluded from the delivered selection; their compiler diagnostics remain in the failed attempt logs. The delivered Kalman entries are init/predict/generic update.
