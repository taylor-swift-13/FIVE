# five-align / 20261103T135838-d67130d489

Verification: blocked

45 new entries generated and audited; 2 modules have explicit frontend gaps. No program-property proofs attempted.

Wall time: 1186.624629 s

CPU tool time: 550.0200000000001 s

Observed tool-tree RSS peak: 1453707264 bytes

Model tokens: available; total=4444683

Measurement completeness: complete

run.json contains scope, input/output hashes, commands, token evidence and remaining obligations. metrics.json contains resource measurements and their limits.

Cost evidence audit: complete
