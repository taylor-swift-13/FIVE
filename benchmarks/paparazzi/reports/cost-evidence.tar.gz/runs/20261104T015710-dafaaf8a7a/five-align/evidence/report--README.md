# Paparazzi align inventory

432 completed entry interfaces. The previous connected-family batch contributed 77 entries.

- [Connected proof families and suggested functional theorems](connected-families.md)
- [Exact source-level call edges](callgraph.json)
- [Bundle models, shared state, hashes and boundaries](proof-bundles.json)
- [All completed entries and recorded gaps](all-results.json)
- [Limitations](limitations.md)
- [Earlier expansion report and common file layout](expansion-README.md)

New family models: `connected-models/<family>/model/Source.v`; each new entry has `entries/<function>/Execution.v` and `proof/{Precondition,Obligations,Proofs}.v`. Interfaces/goal declarations were compiled and generated base declarations kernel-checked. Safety, termination and functional proofs remain pending.

This batch has 9 candidate families, 7 generated/audited, 2 firmware-integration limitations; no pending theorem is treated as a generation failure.

Cost record: `/home/yangfp/five/runs/20261103T144950-76bfe2a685/five-align`. Actual nested tool receipts are aggregated once, including source-closure regeneration; prior run costs are unchanged.

Issue accounting (by family-level issue): 5 discovered, 3 shared-source closure issues resolved, 2 firmware-configuration gaps recorded in limitations.md. These counts exclude pending program proofs.

## Navigation and vision expansion

This batch added **81** entry interfaces across **8** groups.

- [Connected navigation, estimation and vision families](navigation-vision-families.md)
- [All entry results](all-results.json)
- [Compiler and integration limitations](limitations.md)

Models are under `navigation-vision-models/<group>/`. Each entry includes its execution wrapper, explicit precondition interface and pending safety/termination goals.

This batch recorded 3 unresolved import issues by source group. Cost evidence is in `/home/yangfp/five/runs/20261104T015710-dafaaf8a7a/five-align`.

Import issue accounting by group found 5 issues, resolved 2, and recorded 3 unresolved groups.
