# five-align / 20261104T015710-dafaaf8a7a

Verification: passed

81 new entries, 432 cumulative. 3 import limitations. Program proofs pending.

Wall time: 1056.676324 s

CPU tool time: 896.4199999999994 s

Observed tool-tree RSS peak: 1453436928 bytes

Model tokens: available; total=11249542

Measurement completeness: complete

run.json contains scope, input/output hashes, commands, token evidence and remaining obligations. metrics.json contains resource measurements and their limits.

Cost evidence audit: complete
