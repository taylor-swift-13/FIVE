# five-align / 20261103T144950-76bfe2a685

Verification: passed

77 connected entries generated and audited; cumulative 351; 7 proof bundles; no proofs attempted.

Wall time: 890.881128 s

CPU tool time: 546.2999999999997 s

Observed tool-tree RSS peak: 1453977600 bytes

Model tokens: available; total=3157607

Measurement completeness: complete

run.json contains scope, input/output hashes, commands, token evidence and remaining obligations. metrics.json contains resource measurements and their limits.

Cost evidence audit: complete
