# Paparazzi align inventory

274 distinct new-to-FIVE function entries generated and audited across 27 source groups (229 added in this expansion, 45 from the first batch). Existing lowpass, pid and attitude_trig cases were not regenerated. No CBMC or program-property proofs were run.

Source inventory: 7457 recognized definition candidates, including 7138 without parser error flags and 319 requiring review; platform variants and inactive conditional branches are included.

See [limitations.md](limitations.md) for all observed CompCert rejections and affected source/entries.

| Group | Completed entries | Outcome |
|---|---:|---|
| statistics | 7 | generated-and-audited |
| algebra | 8 | generated-and-audited |
| geodetic | 5 | generated-and-audited |
| decomposition | 0 | generation-gap |
| kalman | 3 | generated-and-audited |
| linear_kalman | 0 | generation-gap |
| median | 3 | generated-and-audited |
| highpass | 3 | generated-and-audited |
| notch | 3 | generated-and-audited |
| delay | 4 | generated-and-audited |
| ring_buffer | 5 | generated-and-audited |
| framed_buffer | 4 | generated-and-audited |
| float_vectors_matrices | 43 | generated-and-audited |
| double_algebra | 10 | generated-and-audited |
| double_geodetic | 20 | generated-and-audited |
| float_geodetic_more | 14 | generated-and-audited |
| float_algebra_more | 47 | generated-and-audited |
| integer_algebra | 27 | generated-and-audited |
| atmosphere | 8 | generated-and-audited |
| complementary | 16 | generated-and-audited |
| complementary_arrays | 0 | generation-gap |
| one_euro | 6 | generated-and-audited |
| adaptive_notch | 3 | generated-and-audited |
| delay_arrays | 0 | generation-gap |
| quaternion_filter | 8 | generated-and-audited |
| zoh_filter | 5 | generated-and-audited |
| zoh_arrays | 0 | generation-gap |
| key_value_store | 6 | generated-and-audited |
| median_integer | 3 | generated-and-audited |
| highpass_more | 3 | generated-and-audited |
| notch_more | 3 | generated-and-audited |
| double_vectors | 7 | generated-and-audited |

## Artifact layout

```text
models/<first-batch-group>/
expansion-models/<new-group>/
  Program.c
  model/Source.v
  model/compcert-manifest.json
  entries/<function>/Execution.v
  entries/<function>/proof/Precondition.v
  entries/<function>/proof/Obligations.v
  entries/<function>/proof/Proofs.v
```

Source.v is shared by each source group. Every completed entry has its corresponding unrestricted Cexec interface, separate precondition interface and unproved no-error/all-executions termination goals. The four files for every completed entry were typechecked. Generated base declarations also underwent kernel checking; this is not a proof of the pending program properties. C source definitions are preserved byte-for-byte; implementations, headers and commit are retained under upstream/.

All entry names, source locations, hashes, external symbols and actual provenance audits: [all-results.json](all-results.json). Full project function inventory: [inventory.json](inventory.json).

## Selected entry names

- statistics: `sum_f`, `mean_f`, `variance_f`, `covariance_f`, `mean_i`, `variance_i`, `covariance_i`
- algebra: `float_rmat_comp`, `float_rmat_vmult`, `float_quat_comp`, `float_quat_vmult`, `float_vect3_integrate_fi`, `float_mat_inv_2d`, `float_mat_inv_3d`, `float_rmat_reorthogonalize`
- geodetic: `enu_of_ecef_point_f`, `ned_of_ecef_vect_f`, `ecef_of_enu_point_f`, `ecef_of_lla_f`, `lla_of_ecef_f`
- kalman: `simple_kinematic_kalman_init`, `simple_kinematic_kalman_predict`, `simple_kinematic_kalman_update`
- median: `init_median_filter_f`, `update_median_filter_f`, `get_median_filter_f`
- highpass: `init_first_order_high_pass`, `update_first_order_high_pass`, `update_fourth_order_high_pass`
- notch: `notch_filter_init`, `notch_filter_update`, `notch_filter_set_filter_frequency`
- delay: `init_transport_delay`, `update_transport_delay`, `reset_transport_delay`, `get_transport_delay`
- ring_buffer: `ring_buffer_init`, `ring_buffer_write`, `ring_buffer_read`, `ring_buffer_available`, `ring_buffer_free_space`
- framed_buffer: `framed_ring_buffer_init`, `framed_ring_buffer_get`, `framed_ring_buffer_put`, `framed_ring_buffer_drop_last`
- float_vectors_matrices: `float_log_n`, `float_vect2_norm2`, `float_vect2_norm`, `float_vect2_normalize`, `float_vect3_norm2`, `float_vect3_norm`, `float_vect3_normalize`, `float_rmat_identity`, `float_quat_identity`, `float_quat_norm`, `float_quat_normalize`, `float_quat_invert`, `float_quat_wrap_shortest`, `float_eulers_norm`, `float_vect_zero`, `float_vect_copy`, `float_vect_sum`, `float_vect_diff`, `float_vect_mul`, `float_vect_add`, `float_vect_sub`, `float_vect_smul`, `float_vect_sdiv`, `float_vect_norm`, `float_vect_scale`, `float_vect_dot_product`, `float_mat_zero`, `float_mat_copy`, `float_mat_sum`, `float_mat_diff`, `float_mat_transpose_square`, `float_mat_transpose`, `float_mat_mul`, `float_mat_mul_transpose`, `float_mat_vect_mul`, `float_mat_scale`, `float_mat_sum_scaled`, `float_mat_minor`, `float_mat_vmul`, `float_mat_col`, `float_mat_diagonal_scal`, `float_mat_div_scalar`, `float_mat_mul_scalar`
- double_algebra: `double_rmat_of_eulers_321`, `double_quat_of_eulers`, `double_eulers_of_quat`, `double_quat_vmult`, `double_quat_comp`, `double_rmat_inv`, `double_rmat_comp`, `double_rmat_vmult`, `double_rmat_transp_vmult`, `double_rmat_of_quat`
- double_geodetic: `ltp_def_from_ecef_d`, `ltp_def_from_lla_d`, `lla_of_ecef_d`, `ecef_of_lla_d`, `enu_of_ecef_point_d`, `ned_of_ecef_point_d`, `enu_of_ecef_vect_d`, `ned_of_ecef_vect_d`, `ecef_of_enu_point_d`, `ecef_of_ned_point_d`, `ecef_of_enu_vect_d`, `ecef_of_ned_vect_d`, `enu_of_lla_point_d`, `ned_of_lla_point_d`, `gc_of_gd_lat_d`, `isometric_latitude_d`, `isometric_latitude_fast_d`, `inverse_isometric_latitude_d`, `utm_of_lla_d`, `lla_of_utm_d`
- float_geodetic_more: `ltp_def_from_ecef_f`, `ltp_def_from_lla_f`, `ned_of_ecef_point_f`, `enu_of_ecef_vect_f`, `enu_of_lla_point_f`, `ned_of_lla_point_f`, `ecef_of_ned_point_f`, `ecef_of_enu_vect_f`, `ecef_of_ned_vect_f`, `isometric_latitude_f`, `isometric_latitude_fast_f`, `inverse_isometric_latitude_f`, `utm_of_lla_f`, `lla_of_utm_f`
- float_algebra_more: `float_rates_integrate_fi`, `float_rates_vect3_integrate_fi`, `float_rates_of_euler_dot`, `float_rmat_inv`, `float_rmat_norm`, `float_rmat_comp_inv`, `float_rmat_transp_vmult`, `float_rmat_mult`, `float_rmat_transp_mult`, `float_rmat_ratemult`, `float_rmat_transp_ratemult`, `float_rmat_of_axis_angle`, `float_rmat_of_eulers_312`, `float_rmat_of_quat`, `float_rmat_integrate_fi`, `renorm_factor`, `float_quat_comp_inv`, `float_quat_inv_comp`, `float_quat_comp_norm_shortest`, `float_quat_comp_inv_norm_shortest`, `float_quat_inv_comp_norm_shortest`, `float_quat_differential`, `float_quat_integrate_fi`, `float_quat_integrate`, `float_quat_derivative`, `float_quat_derivative_lagrange`, `float_quat_of_eulers`, `float_quat_of_eulers_zxy`, `float_quat_of_eulers_yxz`, `float_quat_of_axis_angle`, `float_quat_of_orientation_vect`, `float_quat_of_rmat`, `float_quat_tilt_twist`, `float_eulers_of_rmat`, `float_eulers_of_quat_yxz`, `float_eulers_of_quat_zxy`, `float_mat2_mult`, `float_mat3_mult`, `float_mat_minor_4d`, `float_mat_adjoint_4d`, `float_mat_det_4d`, `float_mat_inv_4d`, `float_vect3_bound_in_2d`, `float_vect3_bound_in_3d`, `float_vect3_scale_in_2d`, `float_vect2_bound_in_2d`, `float_vect2_scale_in_2d`
- integer_algebra: `int32_sqrt`, `int32_gcd`, `int32_rmat_comp`, `int32_rmat_comp_inv`, `int32_rmat_vmult`, `int32_rmat_transp_vmult`, `int32_rmat_ratemult`, `int32_rmat_transp_ratemult`, `int32_rmat_of_quat`, `int32_rmat_of_eulers_321`, `int32_rmat_of_eulers_312`, `int32_quat_comp`, `int32_quat_comp_inv`, `int32_quat_inv_comp`, `int32_quat_comp_norm_shortest`, `int32_quat_comp_inv_norm_shortest`, `int32_quat_inv_comp_norm_shortest`, `int32_quat_derivative`, `int32_quat_integrate_fi`, `int32_quat_vmult`, `int32_quat_of_eulers`, `int32_quat_of_axis_angle`, `int32_quat_of_rmat`, `int32_eulers_of_rmat`, `int32_eulers_of_quat`, `int32_rates_of_eulers_dot_321`, `int32_eulers_dot_321_of_rates`
- atmosphere: `pprz_isa_altitude_of_pressure`, `pprz_isa_height_of_pressure`, `pprz_isa_pressure_of_altitude`, `pprz_isa_pressure_of_height`, `pprz_isa_height_of_pressure_full`, `pprz_isa_ref_pressure_of_height_full`, `pprz_isa_temperature_of_altitude`, `pprz_isa_density_of_pressure`
- complementary: `init_first_order_complementary`, `update_first_order_complementary`, `reset_first_order_complementary`, `get_first_order_complementary`, `init_second_order_complementary`, `update_second_order_complementary`, `reset_second_order_complementary`, `get_second_order_complementary`, `init_butterworth_2_complementary`, `update_butterworth_2_complementary`, `reset_butterworth_2_complementary`, `get_butterworth_2_complementary`, `init_butterworth_4_complementary`, `update_butterworth_4_complementary`, `reset_butterworth_4_complementary`, `get_butterworth_4_complementary`
- one_euro: `init_1e_filter`, `reset_1e_filter`, `compute_1e_filter_lp`, `compute_1e_filter_alpha`, `update_1e_filter`, `update_1e_filter_at_time`
- adaptive_notch: `adaptive_notch_filter_init`, `adaptive_notch_filter_update`, `adaptive_notch_filter_get_output`
- quaternion_filter: `init_quat_second_order_low_pass`, `reset_quat_second_order_low_pass`, `update_quat_second_order_low_pass`, `get_quat_second_order_low_pass`, `init_quat_butterworth_low_pass`, `update_quat_butterworth_low_pass`, `reset_quat_butterworth_low_pass`, `get_quat_butterworth_low_pass`
- zoh_filter: `init_first_order_zoh_low_pass`, `update_first_order_zoh_low_pass`, `reset_first_order_zoh_low_pass`, `get_first_order_zoh_low_pass`, `update_first_order_zoh_low_pass_tau`
- key_value_store: `kv_init`, `kv_find`, `kv_exists`, `kv_set`, `kv_get`, `kv_remove`
- median_integer: `init_median_filter_i`, `get_median_filter_i`, `update_median_filter_i`
- highpass_more: `get_first_order_high_pass`, `init_fourth_order_high_pass`, `get_fourth_order_high_pass`
- notch_more: `notch_filter_set_sampling_frequency`, `notch_filter_set_bandwidth`, `notch_filter_get_output`
- double_vectors: `double_vect3_norm`, `double_vect3_normalize`, `double_quat_identity`, `double_quat_norm`, `double_quat_normalize`, `double_rmat_identity`, `double_rmat_of_eulers`

## Costs and scope

Expansion cost record: `/home/yangfp/five/runs/20261103T142645-a9b6ea29fc/five-align`. Historical first-batch cost record is unchanged. Actual nested export/audit command receipts are imported once into this stage; their tools were not otherwise wrapped. Model-token ownership belongs to the measured parent stage. Metrics include retries/failures; no costs are estimated.

Expansion module outcomes: 20 attempted, 17 completed, 3 with recorded limitations. No pending theorem is counted as a generation failure.
