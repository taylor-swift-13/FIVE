# five-align / 20261103T142645-a9b6ea29fc

Verification: passed

229 additional entries generated and audited; cumulative 274; rejected units documented in limitations.md; no program-property proofs.

Wall time: 1162.979553 s

CPU tool time: 1034.819999999999 s

Observed tool-tree RSS peak: 1454592000 bytes

Model tokens: available; total=5385905

Measurement completeness: complete

run.json contains scope, input/output hashes, commands, token evidence and remaining obligations. metrics.json contains resource measurements and their limits.

Cost evidence audit: complete
