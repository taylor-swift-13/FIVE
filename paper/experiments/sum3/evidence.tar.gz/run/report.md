# five-rocq / 20261103T132034-91930463b5

Verification: passed

Actual WP and QCP runs completed; four bit-result theorems kernel checked; CompCert and GCC native executions match CompCert on both inputs.

Wall time: 528.845587 s

CPU tool time: 29.35 s

Observed tool-tree RSS peak: 1351790592 bytes

Model tokens: available; total=2365826

Measurement completeness: partial

run.json contains scope, input/output hashes, commands, token evidence and remaining obligations. metrics.json contains resource measurements and their limits.

Cost evidence audit: incomplete

- Missing sampled tool memory: 013-ccomp-native-run

- Missing sampled tool memory: 014-gcc-native-run
