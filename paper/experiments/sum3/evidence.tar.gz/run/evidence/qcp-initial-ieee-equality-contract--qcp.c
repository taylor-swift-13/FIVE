float sum3(float a, float b, float c)
/*@ Require emp
    Ensure __return == fp32_add(fp32_add(a,b),c) && emp */
{ return a + b + c; }
