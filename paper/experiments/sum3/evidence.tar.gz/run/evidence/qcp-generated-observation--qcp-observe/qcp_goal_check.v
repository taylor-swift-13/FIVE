Require Import qcp_goal qcp_proof_auto qcp_proof_manual.

Module VC_Correctness : VC_Correct.
  Include qcp_proof_auto.
  Include qcp_proof_manual.
End VC_Correctness.
