# five-verify / 20261103T134536-314d123d98

Verification: passed

WP/native comparison completed: native encoding 0x3f800000; WP encoding target unresolved, abstract codec confirmed in exported SMT inputs.

Wall time: 161.496104 s

CPU tool time: 12.17 s

Observed tool-tree RSS peak: 1212907520 bytes

Model tokens: available; total=1141930

Measurement completeness: partial

run.json contains scope, input/output hashes, commands, token evidence and remaining obligations. metrics.json contains resource measurements and their limits.

Cost evidence audit: incomplete

- Missing sampled tool memory: 005-native-run

- Missing sampled tool memory: 008-compcert-run
